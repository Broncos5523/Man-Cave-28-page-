MAN CAVE FANTASY V12

Center-panel update only: replaced the Matchup/Players Remaining/Starters With Points area below win probability with the user-provided Fantasy Football field image. Live Yahoo capture/backend remains unchanged.

MAN CAVE FANTASY V11 - PREMIUM LIVE TV DASHBOARD

1. Extract the ZIP.
2. Copy your WORKING yahoo_chrome_profile folder from V8 into this V11 folder.
3. Double-click START_FANTASY_V11.bat.
4. Browser opens automatically to http://127.0.0.1:5055
5. Press F11 for full-screen TV mode.

NEW IN V11
- Premium centered MAN CAVE FANTASY logo/header.
- Six live matchup score tabs across the bottom.
- Click any matchup tab to jump directly to that matchup.
- Auto-rotation remains enabled every 18 seconds.
- Player headshot support: V11 attempts to use Yahoo player images exposed on the matchup page; initials are used when Yahoo does not expose a usable image.
- Existing live scores, projections, win probability, players remaining, team logos, and starter points remain intact.

IMPORTANT
Leave the black command window open while using the dashboard.
Keep your working yahoo_chrome_profile private; it contains your Yahoo login session.

V11 PREMIUM VISUAL UPDATE
- Uses your custom Man Cave Fantasy Football logo at top center
- Broadcast-style brighter panel outlines and active matchup glow
- Six live matchup tiles remain across the bottom
- Player headshot support retained
- Live Yahoo capture/backend logic retained from the working V9 build
