@echo off
title Man Cave Fantasy - V22 Auto Week Rollover Fix
cd /d "%~dp0"

echo ==============================================================
echo MAN CAVE FANTASY - V14 GAME DAY LIVE TV DASHBOARD
echo ==============================================================
echo.

if not exist "yahoo_chrome_profile" (
  echo ERROR: yahoo_chrome_profile folder is missing.
  echo Copy your working yahoo_chrome_profile folder into this V14 folder.
  echo.
  pause
  exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python was not found.
  pause
  exit /b 1
)

python -c "import flask, playwright" >nul 2>nul
if errorlevel 1 (
  echo Installing required Python packages...
  python -m pip install flask playwright
)

echo Starting dashboard...
echo Your browser will open automatically.
echo Leave this black window open while the dashboard is running.
echo.
python dashboard_server.py

pause
