
import json, re, sys, time, threading, webbrowser
from datetime import datetime, date
from urllib.request import Request, urlopen
from pathlib import Path
from flask import Flask, render_template, jsonify
from playwright.sync_api import sync_playwright

BASE = Path(__file__).resolve().parent
PROFILE = BASE / "yahoo_chrome_profile"
DATA_DIR = BASE / "capture_v8"
DATA_DIR.mkdir(exist_ok=True)
DATA_FILE = DATA_DIR / "dashboard_data.json"

LEAGUE_ID = "957146"
HOME = f"https://football.fantasysports.yahoo.com/f1/{LEAGUE_ID}"
REFRESH_SECONDS = 45
NAV_TIMEOUT_MS = 25000
HEADSHOT_REFRESH_SECONDS = 900
_headshot_cache = {"at": 0.0, "data": {"by_id": {}, "by_name": {}}}

app = Flask(__name__)

NOTE_TOKENS = [
    "Video Forecast", "No new player Notes", "New Player Note",
    "Player Note", "No new player Note"
]

def num(v):
    if v is None:
        return None
    s = str(v).strip().replace(",", "")
    if s in {"", "–", "-", "--"}:
        return 0.0
    try:
        return float(s)
    except:
        return None

def clean_player_blob(blob):
    blob = (blob or "").replace("\r", "").strip()
    lines = [x.strip() for x in blob.split("\n") if x.strip()]
    if not lines:
        return {"name":"", "injury":"", "nfl_team":"", "position":"", "game_status":"", "raw":blob}

    first = lines[0]
    # Yahoo live matchup DOM joins player name + NFL team in the same text node
    # (example: "J. BurrowCin - QB"). Split that live-game format here.
    joined = re.match(r"^(.+?)([A-Z][A-Za-z]{1,3})\s*-\s*([A-Z/]+)$", first)
    joined_team = joined.group(2) if joined else ""
    joined_pos = joined.group(3) if joined else ""
    if joined:
        first = joined.group(1).strip()
    cut = len(first)
    for tok in NOTE_TOKENS:
        i = first.find(tok)
        if i >= 0:
            cut = min(cut, i)
    name_part = first[:cut].strip()

    injury = ""
    m = re.match(r"^(.*?)(CEL|IR|Q|O|D)$", name_part)
    if m and len(m.group(1).strip()) > 2:
        name_part = m.group(1).strip()
        injury = m.group(2)

    nfl_team = joined_team
    position = joined_pos
    game_status = ""
    for line in lines[1:]:
        m = re.match(r"^([A-Za-z]{2,4})\s*-\s*([A-Z/]+)$", line)
        if m:
            nfl_team = m.group(1)
            position = m.group(2)
        elif any(x in line for x in ["Sun ", "Mon ", "Thu ", "Fri ", "Sat ", "Final", "Postponed", "Bye"]):
            game_status = line

    return {
        "name": name_part, "injury": injury, "nfl_team": nfl_team,
        "position": position, "game_status": game_status, "raw": blob
    }

def exact_team_map(links):
    result = {}
    pat = re.compile(rf"^https://football\.fantasysports\.yahoo\.com/f1/{LEAGUE_ID}/(\d+)/?$")
    for x in links:
        href = (x.get("href") or "").strip()
        text = (x.get("text") or "").strip()
        m = pat.match(href)
        if m and text and text.lower() not in {"my team", "overview", "edit team info"}:
            result.setdefault(int(m.group(1)), text)
    return result

def parse_league_standings(tables, team_map):
    """Read Yahoo's displayed league standings in Yahoo's own row order.
    Do not re-rank by win percentage: Yahoo can use points/tiebreakers, so the
    table order is the authoritative current-week league order.
    """
    names = {str(v).strip(): int(k) for k,v in (team_map or {}).items() if str(v).strip()}
    out, seen = [], set()
    rec_re = re.compile(r"^(\d+)\s*[-–]\s*(\d+)(?:\s*[-–]\s*(\d+))?$")
    rank_re = re.compile(r"^(\d{1,2})(?:st|nd|rd|th)?$", re.I)
    for table in tables or []:
        table_rows = []
        for row_obj in table.get("rows", []):
            row = row_obj.get("texts", []) if isinstance(row_obj, dict) else row_obj
            cells = [re.sub(r"\s+", " ", str(x or "")).strip() for x in row]
            joined = " | ".join(cells)
            team_name = next((n for n in names if n and n.lower() in joined.lower()), None)
            if not team_name or team_name in seen:
                continue
            rec = next((rec_re.match(c) for c in cells if rec_re.match(c)), None)
            if not rec:
                continue
            rank = None
            for c in cells[:3]:
                rm = rank_re.match(c.replace('#','').strip())
                if rm:
                    rv = int(rm.group(1))
                    if 1 <= rv <= 20:
                        rank = rv; break
            w,l,t = int(rec.group(1)), int(rec.group(2)), int(rec.group(3) or 0)
            pct = (w + .5*t) / max(1, w+l+t)
            table_rows.append({"team_id": names[team_name], "team_name": team_name,
                               "wins": w, "losses": l, "ties": t,
                               "record": f"{w}-{l}" + (f"-{t}" if t else ""),
                               "win_pct": round(pct,3), "rank": rank})
            seen.add(team_name)
        if len(table_rows) >= 6:
            for i,x in enumerate(table_rows,1):
                if not x.get("rank"): x["rank"] = i
            out.extend(table_rows)
            break
        out.extend(table_rows)
    for i,x in enumerate(out,1):
        if not x.get("rank"): x["rank"] = i
    return out[:12]

def discover_team_ids(links):
    ids = set()
    pat = re.compile(rf"/f1/{LEAGUE_ID}/(\d+)(?:$|[/?#])")
    for x in links:
        m = pat.search(x.get("href", ""))
        if m:
            ids.add(int(m.group(1)))
    return sorted(ids)

def grab_dom(page):
    data = {"url": page.url, "title": page.title()}
    data["links"] = page.locator("a").evaluate_all("""
      els => els.map(a => ({
        text:(a.innerText||a.textContent||'').trim().slice(0,250),
        href:a.href||''
      })).filter(x=>x.text||x.href).slice(0,1500)
    """)
    data["tables"] = page.locator("table").evaluate_all("""
      ts => ts.slice(0,40).map((t,ti)=>({
        index:ti,
        rows:Array.from(t.querySelectorAll('tr')).slice(0,140).map(r => {
          const cells = Array.from(r.querySelectorAll('th,td'));
          return {
            texts: cells.map(c => (c.innerText||c.textContent||'').trim().slice(0,800)),
            players: cells.map((c,ci) => {
              const a = c.querySelector('a.playernote[data-ys-playerid]');
              if (!a) return null;
              return {index:ci, name:(a.innerText||a.textContent||'').trim(), player_id:a.getAttribute('data-ys-playerid')||''};
            }).filter(Boolean)
          };
        })
      }))
    """)
    data["images"] = page.locator("img").evaluate_all("""
      imgs => imgs.slice(0,700).map(img => {
        const a = img.closest('a');
        let e = img.parentElement, context = '';
        for (let i=0; i<6 && e; i++, e=e.parentElement) {
          const t = (e.innerText || '').trim().replace(/\s+/g,' ');
          if (t && t.length <= 220) { context = t; break; }
        }
        return {
          alt: img.alt || '', title: img.title || '',
          src: img.getAttribute('src') || '',
          data_src: img.getAttribute('data-src') || img.getAttribute('data-original') || '',
          current_src: img.currentSrc || '',
          parent_href: a ? (a.href || '') : '',
          context_text: context
        }
      })
    """)
    data["player_ids"] = page.locator("a.playernote[data-ys-playerid]").evaluate_all("""
      els => els.map(a => ({
        name:(a.innerText||a.textContent||'').trim(),
        player_id:a.getAttribute('data-ys-playerid')||''
      })).filter(x=>x.name && x.player_id)
    """)
    data["body_text"] = page.locator("body").inner_text(timeout=15000)[:100000]
    return data

def _norm_name(v):
    return re.sub(r"[^a-z0-9]", "", str(v or "").lower())

def team_logo(images, team_id, team_name):
    """Map the logo from the team-name context surrounding Yahoo's image.
    Live Yahoo removes useful alt text/links, so parent text is the reliable key.
    """
    target = _norm_name(team_name)
    candidates = []
    for im in images or []:
        url = im.get("src") or im.get("data_src") or im.get("current_src") or ""
        if not url:
            continue
        context = _norm_name(im.get("context_text", ""))
        label = _norm_name(" ".join([im.get("alt", ""), im.get("title", "")]))
        low = url.lower()
        score = 0
        if target and target in context:
            score += 60
        if target and target in label:
            score += 45
        if "fantasy-logos" in low:
            score += 20
        elif "/default/nfl/" in low or "image-football-1" in low:
            score += 15
        # Avoid nav/promo art even if it happens to share generic words.
        if any(x in low for x in ["product-switcher", "benefitshub", "flyout", "podcast"]):
            score -= 50
        if score > 0:
            candidates.append((score, url))
    candidates.sort(reverse=True)
    return candidates[0][1] if candidates and candidates[0][0] >= 45 else ""

def fetch_yahoo_player_feed(context=None):
    """Fetch headshots for ALL players in this fantasy league, not just players
    whose NFL games are currently active.

    Yahoo's nfl/players.txt live relay can be game-state dependent. The league
    RedZone JSON is a better source because it includes the fantasy league's
    players (including upcoming games) with imageUrl values.
    """
    result = {"by_id": {}, "by_name": {}}

    # Primary source: league-specific Yahoo fantasy RedZone feed. Use the
    # authenticated Playwright request context so private-league cookies carry
    # over automatically.
    redzone_url = (
        f"https://pub-api.fantasysports.yahoo.com/fantasy/v3/redzone/nfl"
        f"?league_id={LEAGUE_ID}&format=json&player_image_type=17"
    )
    try:
        if context is not None:
            resp = context.request.get(redzone_url, timeout=25000)
            if resp.ok:
                payload = resp.json()

                def walk(x):
                    if isinstance(x, dict):
                        pid = str(x.get("id") or x.get("playerId") or "").strip()
                        name = str(x.get("name") or "").strip()
                        photo = str(x.get("imageUrl") or x.get("image_url") or "").strip()
                        # Player objects in this feed carry a position/team and
                        # imageUrl. This avoids accidentally indexing team art.
                        if pid and name and photo and (x.get("position") or x.get("team")):
                            result["by_id"].setdefault(pid, photo)
                            result["by_name"].setdefault(_norm_name(name), photo)
                        for v in x.values():
                            walk(v)
                    elif isinstance(x, list):
                        for v in x:
                            walk(v)

                walk(payload)
                print(f"  Yahoo league headshots: {len(result['by_id'])} players")
    except Exception as e:
        print("  WARN league headshot feed unavailable:", e)

    # Supplemental/fallback source: Yahoo's NFL player relay. This is useful
    # for names that are not present in the league RedZone payload, but it is
    # no longer relied on as the primary source because it can be partial on
    # game day.
    try:
        url = "https://relay-stream.sports.yahoo.com/nfl/players.txt?"
        req = Request(url, headers={"User-Agent":"Mozilla/5.0"})
        text = urlopen(req, timeout=20).read().decode("utf-8", "ignore")
        for line in text.splitlines():
            if not line.startswith("m|"):
                continue
            parts = line.split("|")
            if len(parts) < 8:
                continue
            pid = parts[1].strip()
            first = parts[4].strip() if len(parts) > 4 else ""
            last = parts[5].strip() if len(parts) > 5 else ""
            photo = parts[6].strip() if len(parts) > 6 else ""
            if pid and photo:
                result["by_id"].setdefault(pid, photo)
                full = _norm_name(first + " " + last)
                if full:
                    result["by_name"].setdefault(full, photo)
        print(f"  Combined headshot index: {len(result['by_id'])} players")
    except Exception as e:
        print("  WARN supplemental player-photo feed unavailable:", e)

    return result

def _player_id_map(player_links):
    out = {}
    for item in player_links or []:
        n = _norm_name(item.get("name", ""))
        pid = str(item.get("player_id", "")).strip()
        if n and pid:
            out.setdefault(n, pid)
    return out

def player_headshot(player_name, player_links, player_feed):
    if not player_name:
        return ""
    n = _norm_name(player_name)
    idmap = _player_id_map(player_links)
    pid = idmap.get(n)
    if pid and pid in player_feed.get("by_id", {}):
        return player_feed["by_id"][pid]

    # Fallback for parser abbreviations such as "J. Burrow".
    # Match first initial + full last name against the feed.
    m = re.match(r"^([a-z])([a-z0-9'’-]+)$", n)
    if m:
        initial, last = m.groups()
        hits = []
        for full, photo in player_feed.get("by_name", {}).items():
            if full.startswith(initial) and full.endswith(last):
                hits.append(photo)
        if len(hits) == 1:
            return hits[0]
    return ""

def add_headshots(players, player_links, player_feed):
    for player in players:
        pid = str(player.get("player_id") or "").strip()
        if pid and pid in player_feed.get("by_id", {}):
            player["headshot_url"] = player_feed["by_id"][pid]
        else:
            player["headshot_url"] = player_headshot(player.get("name", ""), player_links, player_feed)
    return players

def _cell_num(v, live_projection=False):
    vals = re.findall(r"-?\d+(?:\.\d+)?", str(v or ""))
    if not vals:
        return 0.0 if str(v or "").strip() in {"-","–","--"} else None
    # During live games Yahoo puts original projection first and its live-adjusted
    # projection on a second line. Use the live value for player projections.
    return float(vals[-1] if live_projection else vals[0])

def parse_summary(table0):
    out = {}
    rows = table0.get("rows", []) if table0 else []
    for row_obj in rows:
        # V19+ captures row metadata for stable player IDs. Summary parsing only
        # needs the visible cell text, so unwrap the row before using V18 logic.
        row = row_obj.get("texts", []) if isinstance(row_obj, dict) else row_obj
        if len(row) >= 3:
            middle = row[1].strip().lower()
            if middle == "vs":
                out["left_score"] = num(row[0]); out["right_score"] = num(row[2])
            elif "orig proj" in middle:
                out["left_original_projection"] = num(row[0]); out["right_original_projection"] = num(row[2])
            elif "live proj" in middle or "proj pts" in middle:
                out["left_live_projection"] = num(row[0]); out["right_live_projection"] = num(row[2])
    return out

def parse_live_summary_body(body, left_name, right_name):
    """Parse Yahoo's Sunday live score card, which is rendered outside the roster table."""
    out = {}
    # The live page consistently renders: team, record, score, vs., score,
    # original projections, live projected points, opponent team.
    pat = re.compile(
        re.escape(left_name) + r".*?\n\s*(-?\d+(?:\.\d+)?)\s*\n\s*vs\.?\s*\n\s*(-?\d+(?:\.\d+)?)\s*\n"
        r"\s*(-?\d+(?:\.\d+)?)\s*\n\s*Orig Proj\s*\n\s*(-?\d+(?:\.\d+)?)\s*\n"
        r"\s*(-?\d+(?:\.\d+)?)\s*\n\s*Proj Pts\s*\n\s*(-?\d+(?:\.\d+)?)\s*\n"
        + re.escape(right_name), re.I | re.S)
    m = pat.search(body or "")
    if m:
        vals = [float(x) for x in m.groups()]
        out.update(left_score=vals[0], right_score=vals[1],
                   left_original_projection=vals[2], right_original_projection=vals[3],
                   left_live_projection=vals[4], right_live_projection=vals[5])
    return out

def parse_roster_table(table):
    """Parse Yahoo roster rows by locating the actual player anchors.

    Yahoo changes/omits stat columns as NFL games move between upcoming/live/final.
    Fixed column numbers therefore turn projections into player names.  The
    data-ys-playerid anchors are stable, so use those as the row landmarks.
    """
    left, right = [], []
    rows = table.get("rows", []) if table else []
    for row_obj in rows:
        row = row_obj.get("texts", []) if isinstance(row_obj, dict) else row_obj
        players = row_obj.get("players", []) if isinstance(row_obj, dict) else []
        if not row or any(str(x).upper() == "TOTAL" for x in row):
            continue

        # New V19 capture: use Yahoo's player anchors instead of hard-coded cells.
        if len(players) >= 2:
            lp, rp = players[0], players[-1]
            li, ri = int(lp["index"]), int(rp["index"])
            l = clean_player_blob(row[li] if li < len(row) else lp.get("name", ""))
            r = clean_player_blob(row[ri] if ri < len(row) else rp.get("name", ""))
            # Anchor text is the authoritative name; cell text can contain stats.
            anchor_l = (lp.get("name") or "").strip()
            anchor_r = (rp.get("name") or "").strip()
            if anchor_l: l["name"] = anchor_l
            if anchor_r: r["name"] = anchor_r
            # Yahoo table headings can carry player-note markup too. Never count
            # those labels as starters (V19 produced exactly 12 extra rows).
            header_labels = {"player", "fan pts", "proj", "stats", "position", "pos"}
            if l.get("name", "").strip().lower() in header_labels or r.get("name", "").strip().lower() in header_labels:
                continue
            l["player_id"] = str(lp.get("player_id") or "")
            r["player_id"] = str(rp.get("player_id") or "")

            # Slot/position is normally the cell between the two scoring halves.
            middle = row[li+1:ri]
            slot = next((str(x).strip() for x in middle if re.fullmatch(r"QB|RB|WR|TE|W/R/T|K|DEF|BN|IR", str(x).strip(), re.I)), "")

            # Numeric values nearest each player are projection then current score.
            def nums_between(vals):
                out=[]
                for v in vals:
                    n=_cell_num(v, True)
                    if n is not None: out.append(n)
                return out
            ln = nums_between(row[li+1:ri])
            rn = nums_between(row[li+1:ri])[::-1]
            if l["name"] and l["name"] != "(Empty)":
                l.update({"slot":slot, "projected_points":ln[0] if ln else None,
                          "current_points":ln[1] if len(ln)>1 else 0.0, "stats":""})
                left.append(l)
            if r["name"] and r["name"] != "(Empty)":
                r.update({"slot":slot, "projected_points":rn[0] if rn else None,
                          "current_points":rn[1] if len(rn)>1 else 0.0, "stats":""})
                right.append(r)
            continue

        # Backward-compatible fallback for cached/older Yahoo markup.
        if len(row) < 9:
            continue
        l = clean_player_blob(row[1]); r = clean_player_blob(row[7])
        slot = row[4].strip()
        if l["name"] and l["name"] != "(Empty)":
            l.update({"slot":slot, "projected_points":_cell_num(row[2], True),
                      "current_points":_cell_num(row[3]), "stats":row[0].strip()})
            left.append(l)
        if r["name"] and r["name"] != "(Empty)":
            r.update({"slot":slot, "projected_points":_cell_num(row[6], True),
                      "current_points":_cell_num(row[5]), "stats":row[8].strip()})
            right.append(r)
    return left, right

def matchup_pair(data):
    tm = exact_team_map(data["links"])
    body = data.get("body_text","")
    scored = []
    for tid, name in tm.items():
        p = body.find(name)
        if p >= 0: scored.append((p, tid, name))
    scored.sort()
    if len(scored) >= 2:
        return [(x[1], x[2]) for x in scored[:2]]
    return list(tm.items())[:2]

def calendar_fantasy_week():
    """2026 Yahoo/NFL fantasy week rollover: Tuesday after each NFL week."""
    week1_start = date(2026, 9, 8)
    today = datetime.now().date()
    if today < week1_start:
        return 1
    return max(1, min(18, ((today - week1_start).days // 7) + 1))

def current_week(body):
    # Yahoo's markup/text changes during the week. Accept Week 2, Week 2:, etc.
    found = [int(x) for x in re.findall(r"\bWeek\s+(\d{1,2})\b", body or "", re.I)]
    detected = found[0] if found else 1
    # Do not let Yahoo's remembered matchup page pin the dashboard to an older week.
    return max(detected, calendar_fantasy_week())

def remaining_and_odds(body):
    out = {}
    # Live Yahoo uses both "8 Players remaining" and "Players remaining 6".
    before = re.findall(r"(\d+)\s+Players Remaining", body, re.I)
    after = re.findall(r"Players Remaining\s+(\d+)", body, re.I)
    rem = [int(x) for x in before[:1] + after[:1]]
    if rem: out["players_remaining"] = rem
    fav = re.search(r"Favorite\s+(\d+)%", body, re.I)
    dog = re.search(r"(\d+)%\s+Underdog", body, re.I)
    if fav: out["favorite_pct"] = int(fav.group(1))
    if dog: out["underdog_pct"] = int(dog.group(1))
    return out

def parse_summary_any(tables):
    """Yahoo inserts/reorders tables on live game days; scan every table instead of assuming table 0."""
    out = {}
    for table in tables or []:
        got = parse_summary(table)
        for k, v in got.items():
            if v is not None:
                out[k] = v
    return out

def parse_rosters_any(tables):
    """Find the starter/bench roster tables by their contents, not by fixed table indexes."""
    candidates = []
    for i, table in enumerate(tables or []):
        try:
            l, r = parse_roster_table(table)
        except Exception:
            continue
        count = len(l) + len(r)
        if count:
            # Starting lineup is normally the fullest two-sided roster table.
            candidates.append((count, i, l, r))
    candidates.sort(key=lambda x: (-x[0], x[1]))
    if not candidates:
        return [], [], [], []
    _, _, sl, sr = candidates[0]
    bl = br = []
    if len(candidates) > 1:
        _, _, bl, br = candidates[1]
    return sl, sr, bl, br

def load_previous():
    try:
        if DATA_FILE.exists():
            return json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def matchup_key(m):
    try:
        return tuple(sorted((int(m["left"]["team_id"]), int(m["right"]["team_id"]))))
    except Exception:
        return ()

def merge_team(old, new):
    """Never let a transient Yahoo parse failure erase good game-day data."""
    if not old:
        return new
    out = dict(old)
    for k, v in (new or {}).items():
        if k in {"starters", "bench"}:
            if v: out[k] = v
        elif v is not None and v != "":
            out[k] = v
    return out

def merge_matchup(old, new):
    if not old: return new
    if not new: return old
    out = dict(old)
    out.update({k:v for k,v in new.items() if k not in {"left","right"} and v is not None})
    out["left"] = merge_team(old.get("left",{}), new.get("left",{}))
    out["right"] = merge_team(old.get("right",{}), new.get("right",{}))
    return out

def cached_player_feed(context):
    """Headshots change slowly; do not let the image feed hold up live scores."""
    global _headshot_cache
    now = time.time()
    if now - _headshot_cache["at"] < HEADSHOT_REFRESH_SECONDS and _headshot_cache["data"]["by_id"]:
        return _headshot_cache["data"]
    try:
        data = fetch_yahoo_player_feed(context)
        if data.get("by_id") or data.get("by_name"):
            _headshot_cache = {"at": now, "data": data}
            return data
    except Exception as e:
        print("  WARN headshot refresh skipped:", e, flush=True)
    return _headshot_cache["data"]

def nav_live(page, url, pause=1.5):
    """Navigate with a short timeout and explicit no-cache semantics for game-day data."""
    sep = "&" if "?" in url else "?"
    live_url = f"{url}{sep}_mc={int(time.time()*1000)}"
    page.goto(live_url, wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
    time.sleep(pause)

def capture_once():
    if not PROFILE.exists():
        raise RuntimeError("yahoo_chrome_profile folder is missing.")

    previous = load_previous()
    previous_by_team = {}
    for pm in previous.get("matchups", []):
        for side in ("left", "right"):
            try: previous_by_team[int(pm[side]["team_id"])] = pm
            except Exception: pass

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(PROFILE), channel="chrome", headless=True,
            viewport={"width":1280,"height":720},
            args=["--disable-gpu","--disable-extensions","--disable-background-networking",
                  "--disable-default-apps","--disable-sync","--no-first-run"],
        )
        def route_handler(route):
            if route.request.resource_type in {"image","media","font"}: route.abort()
            else: route.continue_()
        context.route("**/*", route_handler)
        page = context.pages[0] if context.pages else context.new_page()
        try:
            print(f"[{time.strftime('%I:%M:%S %p')}] Yahoo refresh starting...", flush=True)
            nav_live(page, HOME, 1.5)
            if "login.yahoo.com" in page.url.lower():
                raise RuntimeError("Yahoo login expired. Reuse your working profile/sign in again.")

            home = grab_dom(page)
            team_ids = discover_team_ids(home["links"])
            standings = parse_league_standings(home.get("tables", []), exact_team_map(home.get("links", [])))

            nav_live(page, f"{HOME}/matchup", 1.5)
            week_data = grab_dom(page)
            week = current_week(week_data["body_text"])
            print(f"Yahoo week target: {week} (calendar week {calendar_fantasy_week()})")
            player_feed = cached_player_feed(context)

            seen = set()
            matchups = []
            for tid in team_ids:
                url = f"{HOME}/matchup?week={week}&module=matchup&mid1={tid}"
                try:
                    nav_live(page, url, 1.25)
                    data = grab_dom(page)
                except Exception as e:
                    print(f"  WARN team {tid}: live page refresh failed: {e}", flush=True)
                    continue
                pair = matchup_pair(data)
                if len(pair) != 2 and tid in previous_by_team:
                    pm = previous_by_team[tid]
                    pair = [(pm["left"]["team_id"], pm["left"]["team_name"]),
                            (pm["right"]["team_id"], pm["right"]["team_name"])]
                if len(pair) != 2:
                    print(f"  WARN team {tid}: could not identify opponent")
                    continue
                pair_ids = tuple(sorted([pair[0][0], pair[1][0]]))
                if pair_ids in seen: continue
                seen.add(pair_ids)

                left_id, left_name = pair[0]
                right_id, right_name = pair[1]
                tables = data.get("tables", [])
                summary = parse_summary_any(tables)
                # Sunday live score card is outside the tables captured by V14.
                summary.update(parse_live_summary_body(data.get("body_text", ""), left_name, right_name))
                sl, sr, bl, br = parse_rosters_any(tables)
                images = data.get("images", [])
                player_links = data.get("player_ids", [])
                add_headshots(sl, player_links, player_feed); add_headshots(sr, player_links, player_feed)
                add_headshots(bl, player_links, player_feed); add_headshots(br, player_links, player_feed)
                extra = remaining_and_odds(data["body_text"])

                m = {
                    "week":week, "url":page.url,
                    "left":{
                        "team_id":left_id,"team_name":left_name,
                        "logo_url":team_logo(data.get("images",[]),left_id,left_name),
                        "score":summary.get("left_score"),
                        "original_projection":summary.get("left_original_projection"),
                        "live_projection":summary.get("left_live_projection"),
                        "starters":sl,"bench":bl
                    },
                    "right":{
                        "team_id":right_id,"team_name":right_name,
                        "logo_url":team_logo(data.get("images",[]),right_id,right_name),
                        "score":summary.get("right_score"),
                        "original_projection":summary.get("right_original_projection"),
                        "live_projection":summary.get("right_live_projection"),
                        "starters":sr,"bench":br
                    },
                    "meta":extra
                }
                rem = extra.get("players_remaining",[])
                if len(rem)>0: m["left"]["players_remaining"]=rem[0]
                if len(rem)>1: m["right"]["players_remaining"]=rem[1]
                if "favorite_pct" in extra: m["left"]["win_probability"]=extra["favorite_pct"]
                if "underdog_pct" in extra: m["right"]["win_probability"]=extra["underdog_pct"]
                matchups.append(m)

            # Merge this refresh into the last known-good six-matchup snapshot.
            # Yahoo can temporarily omit/reorder live matchup tables during Sunday games.
            # Only carry forward a snapshot from THIS week. Never merge last week's
            # completed scores/lineups into a newly rolled-over Yahoo week.
            previous_same_week = previous if int(previous.get("week", 0) or 0) == int(week) else {}
            old_by_key = {matchup_key(x): x for x in previous_same_week.get("matchups", []) if matchup_key(x)}
            new_by_key = {matchup_key(x): x for x in matchups if matchup_key(x)}
            merged = []
            all_keys = list(old_by_key)
            for k in new_by_key:
                if k not in all_keys: all_keys.append(k)
            for k in all_keys:
                merged.append(merge_matchup(old_by_key.get(k), new_by_key.get(k)))

            # First run has no previous snapshot, so use what we captured.
            if not merged:
                merged = matchups

            payload = {
                "league_id":LEAGUE_ID, "league_name":"Bryan's Football League",
                "week":week, "team_count":len(team_ids), "matchup_count":len(merged),
                "captured_at_unix":time.time(), "standings":standings, "matchups":merged
            }

            # Atomic write: dashboard never sees a half-written JSON file.
            tmp = DATA_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            tmp.replace(DATA_FILE)

            score_ok = sum(1 for m in merged if m.get("left",{}).get("score") is not None and m.get("right",{}).get("score") is not None)
            lineup_ok = sum(1 for m in merged if m.get("left",{}).get("starters") and m.get("right",{}).get("starters"))
            players = sum(len(m.get("left",{}).get("starters",[]))+len(m.get("right",{}).get("starters",[])) for m in merged)
            print(f"[{time.strftime('%I:%M:%S %p')}] LIVE UPDATE: captured {len(matchups)} | serving {len(merged)} matchups | scores {score_ok}/{len(merged)} | lineups {lineup_ok}/{len(merged)} | starters {players}", flush=True)
        finally:
            context.close()

def updater_loop():
    while True:
        try:
            capture_once()
        except Exception as e:
            print(f"[{time.strftime('%I:%M:%S %p')}] Update error: {e}", flush=True)
        time.sleep(REFRESH_SECONDS)

@app.route("/")
def index():
    return render_template("dashboard.html")

@app.route("/api/data")
def api_data():
    if not DATA_FILE.exists():
        return jsonify({"loading":True, "message":"First Yahoo refresh is still running."})
    try:
        return jsonify(json.loads(DATA_FILE.read_text(encoding="utf-8")))
    except Exception as e:
        return jsonify({"error":str(e)}), 500

def open_browser():
    time.sleep(3)
    webbrowser.open("http://127.0.0.1:5055")

if __name__ == "__main__":
    print("="*70)
    print("MAN CAVE FANTASY - V23 LIVE REFRESH WATCHDOG")
    print("="*70)
    print("Yahoo refresh: every 45 seconds (V23 live no-cache refresh)")
    print("Dashboard: http://127.0.0.1:5055")
    print("Leave this black window open while the TV dashboard is running.")
    print()

    threading.Thread(target=updater_loop, daemon=True).start()
    threading.Thread(target=open_browser, daemon=True).start()
    app.run(host="127.0.0.1", port=5055, debug=False, use_reloader=False)
